import { serve } from 'https://deno.land/std@0.177.0/http/server.ts'
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders })
  }

  try {
    // Create a Supabase client with the Auth context of the logged in user
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_ANON_KEY') ?? '',
      { global: { headers: { Authorization: req.headers.get('Authorization')! } } }
    )

    const { patientId, timePeriod } = await req.json()

    if (!patientId) {
      return new Response(
        JSON.stringify({ error: 'Patient ID is required' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      )
    }

    // Calculate analytics based on recent sessions
    let dateFilter = new Date()
    switch (timePeriod) {
      case 'daily':
        dateFilter.setDate(dateFilter.getDate() - 1)
        break
      case 'weekly':
        dateFilter.setDate(dateFilter.getDate() - 7)
        break
      case 'monthly':
        dateFilter.setMonth(dateFilter.getMonth() - 1)
        break
      default:
        dateFilter.setDate(dateFilter.getDate() - 7) // Default to weekly
    }

    // Get session progress data
    const { data: progressData, error: progressError } = await supabaseClient
      .from('session_progress')
      .select(`
        accuracy_percentage,
        session_id,
        therapy_sessions!inner(
          patient_id,
          created_at,
          session_duration
        )
      `)
      .eq('therapy_sessions.patient_id', patientId)
      .gte('therapy_sessions.created_at', dateFilter.toISOString())

    if (progressError) {
      throw progressError
    }

    // Calculate metrics
    const accuracies = progressData?.map(p => p.accuracy_percentage) || []
    const sessions = new Set(progressData?.map(p => p.session_id) || [])
    
    const averageAccuracy = accuracies.length > 0 
      ? accuracies.reduce((sum, acc) => sum + acc, 0) / accuracies.length 
      : 0
    
    const sessionCount = sessions.size
    
    // Calculate improvement rate (simplified)
    const improvementRate = averageAccuracy > 75 ? 
      Math.min(((averageAccuracy - 75) / 25) * 100, 100) : 0

    // Store analytics
    const analyticsData = [
      {
        patient_id: patientId,
        metric_name: 'average_accuracy',
        metric_value: averageAccuracy,
        time_period: timePeriod || 'weekly'
      },
      {
        patient_id: patientId,
        metric_name: 'session_count',
        metric_value: sessionCount,
        time_period: timePeriod || 'weekly'
      },
      {
        patient_id: patientId,
        metric_name: 'improvement_rate',
        metric_value: improvementRate,
        time_period: timePeriod || 'weekly'
      }
    ]

    const { error: upsertError } = await supabaseClient
      .from('patient_analytics')
      .upsert(analyticsData, { 
        onConflict: 'patient_id,metric_name,time_period',
        ignoreDuplicates: false 
      })

    if (upsertError) {
      throw upsertError
    }

    return new Response(
      JSON.stringify({ 
        success: true, 
        analytics: analyticsData,
        message: `Analytics calculated for ${sessionCount} sessions with ${averageAccuracy.toFixed(1)}% average accuracy`
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    )

  } catch (error) {
    return new Response(
      JSON.stringify({ error: error.message }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    )
  }
})