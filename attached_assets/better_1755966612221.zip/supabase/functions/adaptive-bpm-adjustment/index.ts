import { serve } from 'https://deno.land/std@0.177.0/http/server.ts'
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders })
  }

  try {
    // Create a Supabase client with the Auth context of the logged in user
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_ANON_KEY') ?? '',
      { global: { headers: { Authorization: req.headers.get('Authorization')! } } }
    )

    const { sessionId, currentAccuracy, currentBPM, patientId } = await req.json()

    if (!sessionId || !patientId) {
      return new Response(
        JSON.stringify({ error: 'Session ID and Patient ID are required' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      )
    }

    // Get patient's baseline and target BPM
    const { data: patient, error: patientError } = await supabaseClient
      .from('profiles')
      .select('baseline_bpm, target_bpm')
      .eq('id', patientId)
      .single()

    if (patientError || !patient) {
      throw new Error('Patient not found')
    }

    // Get recent session progress to analyze performance
    const { data: recentProgress, error: progressError } = await supabaseClient
      .from('session_progress')
      .select('accuracy_percentage, current_bpm')
      .eq('session_id', sessionId)
      .order('created_at', { ascending: false })
      .limit(10)

    if (progressError) {
      throw progressError
    }

    // Calculate adaptive BPM adjustment based on AI logic
    let recommendedBPM = currentBPM
    let adjustment = 0
    let reason = 'Maintaining current tempo'

    if (recentProgress && recentProgress.length >= 3) {
      const recentAccuracies = recentProgress.map(p => p.accuracy_percentage)
      const averageAccuracy = recentAccuracies.reduce((sum, acc) => sum + acc, 0) / recentAccuracies.length

      // AI-driven adaptive logic
      if (averageAccuracy >= 85 && currentAccuracy >= 85) {
        // Patient performing well - gradually increase challenge
        adjustment = Math.min(3, (patient.target_bpm - currentBPM) * 0.1)
        recommendedBPM = Math.min(currentBPM + adjustment, patient.target_bpm)
        reason = 'Excellent performance - increasing challenge'
      } else if (averageAccuracy < 70) {
        // Patient struggling - reduce tempo
        adjustment = -Math.max(2, (currentBPM - patient.baseline_bpm) * 0.15)
        recommendedBPM = Math.max(currentBPM + adjustment, patient.baseline_bpm)
        reason = 'Performance below target - reducing tempo for success'
      } else if (currentAccuracy < 60) {
        // Immediate adjustment needed
        adjustment = -5
        recommendedBPM = Math.max(currentBPM + adjustment, patient.baseline_bpm)
        reason = 'Immediate accuracy drop - reducing tempo'
      } else if (averageAccuracy >= 75 && averageAccuracy < 85) {
        // Gradual improvement
        adjustment = 1
        recommendedBPM = Math.min(currentBPM + adjustment, patient.target_bpm)
        reason = 'Steady progress - slight increase'
      }
    }

    // Ensure BPM stays within safe clinical ranges
    recommendedBPM = Math.max(60, Math.min(180, recommendedBPM))

    // Log the adaptive decision
    const adaptiveLog = {
      session_id: sessionId,
      original_bpm: currentBPM,
      recommended_bpm: recommendedBPM,
      adjustment: adjustment,
      current_accuracy: currentAccuracy,
      reason: reason,
      timestamp: new Date().toISOString()
    }

    // Store adaptive decision (you might want to create an adaptive_logs table)
    console.log('Adaptive BPM Decision:', adaptiveLog)

    return new Response(
      JSON.stringify({ 
        success: true,
        originalBPM: currentBPM,
        recommendedBPM: Math.round(recommendedBPM * 100) / 100, // Round to 2 decimal places
        adjustment: Math.round(adjustment * 100) / 100,
        reason: reason,
        confidence: averageAccuracy > 75 ? 'high' : averageAccuracy > 60 ? 'medium' : 'low'
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    )

  } catch (error) {
    return new Response(
      JSON.stringify({ error: error.message }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    )
  }
})