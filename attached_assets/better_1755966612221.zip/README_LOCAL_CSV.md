# Running Neuro-Beat-Rhythm locally with CSV storage

This fork removes Supabase and replaces it with a tiny local Node/Express API that writes CSV files.

## Steps

1. Install deps
```bash
npm install
```
2. Run the CSV API server
```bash
npm run server
```
This starts `http://localhost:5000` and creates CSV files under `./data/`.

3. Run the frontend
```bash
npm run dev
```
Open the URL Vite prints (e.g., `http://localhost:5173`).

## Environment (optional)
Create `.env` with:
```
VITE_API_URL=http://localhost:5000
```

## CSV files
- `data/users.csv`
- `data/therapy_sessions.csv`
- `data/session_progress.csv`