import express from 'express';
import fs from 'fs';
import path from 'path';
import cors from 'cors';
import bodyParser from 'body-parser';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
app.use(cors());
app.use(bodyParser.json());

// Data directory
const DATA_DIR = path.join(__dirname, 'data');
if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR);

// CSV file paths
const USERS_CSV = path.join(DATA_DIR, 'users.csv');
const SESSIONS_CSV = path.join(DATA_DIR, 'therapy_sessions.csv');
const PROGRESS_CSV = path.join(DATA_DIR, 'session_progress.csv');

// Ensure CSV headers
if (!fs.existsSync(USERS_CSV)) fs.writeFileSync(USERS_CSV, 'id,email,full_name,role,condition,baseline_bpm,password\n');
if (!fs.existsSync(SESSIONS_CSV)) fs.writeFileSync(SESSIONS_CSV, 'id,patient_id,clinician_id,bpm,notes,created_at,status\n');
if (!fs.existsSync(PROGRESS_CSV)) fs.writeFileSync(PROGRESS_CSV, 'id,patient_id,session_id,time_period,steps,symptom_score,created_at\n');

function genId() { return Math.random().toString(36).slice(2); }
function nowISO() { return new Date().toISOString(); }

function readCSV(file) {
  const txt = fs.readFileSync(file, 'utf8').trim();
  if (!txt) return { header: [], rows: [] };
  const [headerLine, ...lines] = txt.split(/\r?\n/);
  const header = headerLine.split(',');
  const rows = lines.filter(Boolean).map(line => {
    const cols = line.split(',');
    const obj = {};
    header.forEach((h, i) => obj[h] = cols[i] ?? '');
    return obj;
  });
  return { header, rows };
}

function appendCSV(file, rowObj) {
  const { header } = readCSV(file);
  const line = header.map(h => (rowObj[h] ?? '').toString().replace(/\n|\r|,/g, ' ')).join(',');
  fs.appendFileSync(file, (fs.readFileSync(file, 'utf8').endsWith('\n') ? '' : '\n') + line + '\n');
}

// -------- AUTH --------
app.post('/auth/signup', (req, res) => {
  const { email, password, full_name, role='patient', condition='', baseline_bpm='' } = req.body;
  const { rows } = readCSV(USERS_CSV);
  if (rows.find(u => u.email === email)) {
    return res.status(400).json({ error: 'User already exists' });
  }
  const user = {
    id: genId(),
    email,
    full_name: full_name || '',
    role,
    condition,
    baseline_bpm: baseline_bpm?.toString() || '',
    password
  };
  appendCSV(USERS_CSV, user);
  return res.json({ user: { ...user, password: undefined } });
});

app.post('/auth/signin', (req, res) => {
  const { email, password } = req.body;
  const { rows } = readCSV(USERS_CSV);
  const user = rows.find(u => u.email === email && u.password === password);
  if (!user) return res.status(400).json({ error: 'Invalid credentials' });
  return res.json({ user: { ...user, password: undefined } });
});

app.get('/profiles/:id', (req, res) => {
  const { id } = req.params;
  const { rows } = readCSV(USERS_CSV);
  const user = rows.find(u => u.id === id);
  if (!user) return res.status(404).json({ error: 'Not found' });
  return res.json({ profile: { ...user, password: undefined } });
});

// -------- THERAPY SESSIONS --------
app.post('/sessions', (req, res) => {
  const { patient_id, clinician_id='', bpm='', notes='', status='active' } = req.body;
  const session = {
    id: genId(),
    patient_id,
    clinician_id,
    bpm: bpm?.toString() || '',
    notes: (notes || '').toString().replace(/\n|\r|,/g, ' '),
    created_at: nowISO(),
    status
  };
  appendCSV(SESSIONS_CSV, session);
  return res.json({ session });
});

app.put('/sessions/:id', (req, res) => {
  const { id } = req.params;
  const { bpm, notes, status } = req.body;
  const data = readCSV(SESSIONS_CSV);
  let found = false;
  const updated = data.rows.map(r => {
    if (r.id === id) {
      found = true;
      return {
        ...r,
        bpm: bpm !== undefined ? String(bpm) : r.bpm,
        notes: notes !== undefined ? String(notes).replace(/\n|\r|,/g, ' ') : r.notes,
        status: status !== undefined ? String(status) : r.status,
      };
    }
    return r;
  });
  if (!found) return res.status(404).json({ error: 'Session not found' });
  // rewrite file
  const header = data.header.join(',') + '\n';
  const lines = updated.map(r => data.header.map(h => (r[h] ?? '').toString().replace(/\n|\r|,/g, ' ')).join(',')).join('\n') + '\n';
  fs.writeFileSync(SESSIONS_CSV, header + lines);
  return res.json({ ok: true });
});

app.get('/sessions/:patientId', (req, res) => {
  const { patientId } = req.params;
  const limit = parseInt(req.query.limit ?? '10');
  const { rows } = readCSV(SESSIONS_CSV);
  const list = rows.filter(r => r.patient_id === patientId).sort((a,b) => (a.created_at > b.created_at ? -1 : 1)).slice(0, limit);
  return res.json({ sessions: list });
});

// -------- PROGRESS / ANALYTICS --------
app.post('/progress', (req, res) => {
  const { patient_id, session_id, time_period='daily', steps=0, symptom_score=0 } = req.body;
  const rec = {
    id: genId(),
    patient_id,
    session_id,
    time_period,
    steps: String(steps),
    symptom_score: String(symptom_score),
    created_at: nowISO()
  };
  appendCSV(PROGRESS_CSV, rec);
  return res.json({ progress: rec });
});

app.get('/analytics/:patientId', (req, res) => {
  const { patientId } = req.params;
  const time_period = req.query.time_period ?? 'daily';
  const { rows } = readCSV(PROGRESS_CSV);
  const list = rows.filter(r => r.patient_id === patientId && r.time_period === time_period);
  // simple aggregates
  const count = list.length || 1;
  const avg_steps = Math.round(list.reduce((s, r) => s + (parseInt(r.steps||'0')||0), 0) / count);
  const avg_symptom = Math.round(list.reduce((s, r) => s + (parseInt(r.symptom_score||'0')||0), 0) / count);
  return res.json({ analytics: { avg_steps, avg_symptom, samples: list.length } });
});

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`CSV API server running at http://localhost:${PORT}`));