// Local CSV-backed API wrapper (replaces Supabase client)

export interface User {
  id: string;
  email: string;
  full_name: string;
  role: 'patient' | 'clinician' | 'admin';
  condition?: 'parkinsons' | 'stroke' | 'other' | '';
  baseline_bpm?: number | string;
}

export interface Profile extends User {}

const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:5000';

// -------- Auth --------
export const signUp = async (email: string, password: string, full_name: string, role: User['role'], condition?: string, baseline_bpm?: number) => {
  const res = await fetch(`${API_URL}/auth/signup`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email, password, full_name, role, condition, baseline_bpm })
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error || 'Signup failed');
  }
  const data = await res.json();
  const user: User = data.user;
  // store session locally
  localStorage.setItem('nbr_current_user', JSON.stringify(user));
  return { user };
};

export const signIn = async (email: string, password: string) => {
  const res = await fetch(`${API_URL}/auth/signin`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email, password })
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error || 'Sign in failed');
  }
  const data = await res.json();
  const user: User = data.user;
  localStorage.setItem('nbr_current_user', JSON.stringify(user));
  return { user };
};

export const signOut = async () => {
  localStorage.removeItem('nbr_current_user');
};

export const getCurrentUser = async () => {
  const raw = localStorage.getItem('nbr_current_user');
  const user = raw ? (JSON.parse(raw) as User) : null;
  return { data: user };
};

export const getProfile = async (userId: string) => {
  const res = await fetch(`${API_URL}/profiles/${userId}`);
  if (!res.ok) return { data: null, error: new Error('Profile not found') };
  const { profile } = await res.json();
  return { data: profile as Profile, error: null };
};

// -------- Therapy Sessions --------
export const createTherapySession = async (patientId: string, sessionData: { clinician_id?: string; bpm?: number; notes?: string; status?: string }) => {
  const res = await fetch(`${API_URL}/sessions`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ patient_id: patientId, ...sessionData })
  });
  if (!res.ok) return { data: null, error: new Error('Failed to create session') };
  const { session } = await res.json();
  return { data: session, error: null };
};

export const updateTherapySession = async (sessionId: string, updates: any) => {
  const res = await fetch(`${API_URL}/sessions/${sessionId}`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(updates)
  });
  if (!res.ok) return { error: new Error('Failed to update session') };
  return { error: null };
};

export const recordSessionProgress = async (patientId: string, sessionId: string, progress: { time_period?: string; steps?: number; symptom_score?: number; }) => {
  const res = await fetch(`${API_URL}/progress`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ patient_id: patientId, session_id: sessionId, ...progress })
  });
  if (!res.ok) return { error: new Error('Failed to record progress') };
  return { error: null };
};

export const getPatientAnalytics = async (patientId: string, timePeriod: string = 'daily') => {
  const res = await fetch(`${API_URL}/analytics/${patientId}?time_period=${encodeURIComponent(timePeriod)}`);
  if (!res.ok) return { data: null, error: new Error('Failed to load analytics') };
  const { analytics } = await res.json();
  return { data: analytics, error: null };
};

export const getPatientSessions = async (patientId: string, limit: number = 10) => {
  const res = await fetch(`${API_URL}/sessions/${patientId}?limit=${limit}`);
  if (!res.ok) return { data: null, error: new Error('Failed to load sessions') };
  const { sessions } = await res.json();
  return { data: sessions, error: null };
};