import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { Play, Pause, RotateCcw, LogOut } from 'lucide-react';
import { BeatVisualizer } from './BeatVisualizer';
import { useAuth } from '@/hooks/useAuth';
import { createTherapySession, updateTherapySession, recordSessionProgress, TherapySession } from '@/lib/supabase';
import { useToast } from '@/hooks/use-toast';

interface EnhancedPatientInterfaceProps {
  targetBPM: number;
  onProgressUpdate: (progress: { accuracy: number; session_time: number }) => void;
}

export const EnhancedPatientInterface = ({ targetBPM, onProgressUpdate }: EnhancedPatientInterfaceProps) => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [sessionTime, setSessionTime] = useState(0);
  const [currentBPM, setCurrentBPM] = useState(targetBPM);
  const [accuracy, setAccuracy] = useState(85);
  const [sessionProgress, setSessionProgress] = useState(0);
  const [currentSession, setCurrentSession] = useState<TherapySession | null>(null);
  const [bpmHistory, setBpmHistory] = useState<number[]>([]);
  const [accuracyHistory, setAccuracyHistory] = useState<number[]>([]);
  
  const { user, profile, signOut } = useAuth();
  const { toast } = useToast();

  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (isPlaying && currentSession) {
      interval = setInterval(async () => {
        const newSessionTime = sessionTime + 1;
        setSessionTime(newSessionTime);
        setSessionProgress(prev => Math.min(prev + 0.33, 100)); // 5-minute session
        
        // Simulate adaptive BPM adjustment
        const variation = Math.sin(Date.now() / 2000) * 2;
        const newBPM = targetBPM + variation;
        setCurrentBPM(newBPM);
        
        // Simulate changing accuracy with slight improvement over time
        const baseAccuracy = 75 + Math.random() * 20;
        const improvementFactor = Math.min(newSessionTime / 300, 0.1); // Small improvement over 5 minutes
        const newAccuracy = baseAccuracy + (improvementFactor * 10);
        setAccuracy(newAccuracy);
        
        // Update histories
        setBpmHistory(prev => [...prev.slice(-59), newBPM]); // Keep last 60 readings
        setAccuracyHistory(prev => [...prev.slice(-59), newAccuracy]);
        
        // Record progress in database
        try {
          await recordSessionProgress({
            session_id: currentSession.id,
            timestamp_offset: newSessionTime,
            current_bpm: newBPM,
            accuracy_percentage: newAccuracy,
            step_count: Math.floor(newSessionTime * (newBPM / 60))
          });
        } catch (error) {
          console.error('Error recording progress:', error);
        }
        
        onProgressUpdate({ accuracy: newAccuracy, session_time: newSessionTime });
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [isPlaying, sessionTime, targetBPM, onProgressUpdate, currentSession]);

  const handleStartStop = async () => {
    if (!isPlaying && !currentSession) {
      // Start new session
      try {
        const { data: session, error } = await createTherapySession({
          patient_id: user?.id,
          session_type: 'gait_training',
          target_bpm: targetBPM,
          actual_bpm: [],
          accuracy_scores: [],
          session_duration: 0,
          status: 'active'
        });

        if (error) throw error;
        
        setCurrentSession(session);
        setIsPlaying(true);
        
        toast({
          title: "Session started",
          description: "Your gait training session has begun.",
        });
      } catch (error) {
        toast({
          title: "Error starting session",
          description: "Could not start therapy session.",
          variant: "destructive"
        });
      }
    } else if (isPlaying && currentSession) {
      // Pause session
      setIsPlaying(false);
      
      try {
        await updateTherapySession(currentSession.id, {
          status: 'paused'
        });
      } catch (error) {
        console.error('Error pausing session:', error);
      }
    } else if (!isPlaying && currentSession) {
      // Resume session
      setIsPlaying(true);
      
      try {
        await updateTherapySession(currentSession.id, {
          status: 'active'
        });
      } catch (error) {
        console.error('Error resuming session:', error);
      }
    }
  };

  const handleComplete = async () => {
    if (currentSession) {
      try {
        await updateTherapySession(currentSession.id, {
          status: 'completed',
          session_duration: sessionTime,
          actual_bpm: bpmHistory,
          accuracy_scores: accuracyHistory,
          completed_at: new Date().toISOString()
        });

        toast({
          title: "Session completed!",
          description: `Great job! You completed a ${Math.floor(sessionTime / 60)}:${(sessionTime % 60).toString().padStart(2, '0')} session with ${Math.round(accuracy)}% accuracy.`,
        });

        handleReset();
      } catch (error) {
        toast({
          title: "Error completing session",
          description: "Could not save session data.",
          variant: "destructive"
        });
      }
    }
  };

  const handleReset = () => {
    setIsPlaying(false);
    setSessionTime(0);
    setSessionProgress(0);
    setAccuracy(85);
    setCurrentSession(null);
    setBpmHistory([]);
    setAccuracyHistory([]);
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <div className="space-y-6">
      {/* Header with user info and logout */}
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-3xl font-bold text-foreground">Welcome, {profile?.full_name}</h2>
          <div className="flex items-center space-x-2 mt-1">
            <Badge variant="secondary">
              {profile?.condition === 'parkinsons' ? "Parkinson's Disease" : 
               profile?.condition === 'stroke' ? "Stroke Recovery" : "Other"}
            </Badge>
            <Badge variant="outline">Patient</Badge>
          </div>
        </div>
        <Button variant="outline" onClick={signOut} className="flex items-center space-x-2">
          <LogOut className="w-4 h-4" />
          <span>Sign Out</span>
        </Button>
      </div>

      {/* Session Status */}
      {currentSession && (
        <Card className="p-4 bg-gradient-calm">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <div className={`w-3 h-3 rounded-full ${isPlaying ? 'bg-success animate-pulse' : 'bg-accent'}`} />
              <span className="text-sm font-medium">
                {isPlaying ? 'Session Active' : 'Session Paused'}
              </span>
            </div>
            <div className="text-sm text-muted-foreground">
              Session ID: {currentSession.id.slice(-8)}
            </div>
          </div>
        </Card>
      )}

      {/* Main Control Card */}
      <Card className="p-8 space-y-6 shadow-medical">
        <div className="text-center space-y-4">
          <div className="text-6xl font-bold text-primary">
            {Math.round(currentBPM)}
          </div>
          <div className="text-sm text-muted-foreground uppercase tracking-wide">
            Beats Per Minute
          </div>
        </div>

        {/* Beat Visualizer */}
        <BeatVisualizer isPlaying={isPlaying} bpm={currentBPM} />

        {/* Controls */}
        <div className="flex justify-center space-x-4">
          <Button
            size="lg"
            onClick={handleStartStop}
            className="w-20 h-20 rounded-full text-lg shadow-therapeutic"
            variant={isPlaying ? "secondary" : "default"}
          >
            {isPlaying ? <Pause className="w-8 h-8" /> : <Play className="w-8 h-8" />}
          </Button>
          
          {sessionProgress >= 100 && (
            <Button
              size="lg"
              onClick={handleComplete}
              className="w-20 h-20 rounded-full bg-success hover:bg-success/90"
            >
              Complete
            </Button>
          )}
          
          <Button
            size="lg"
            variant="outline"
            onClick={handleReset}
            className="w-20 h-20 rounded-full"
          >
            <RotateCcw className="w-6 h-6" />
          </Button>
        </div>
      </Card>

      {/* Progress Panel */}
      <Card className="p-6 space-y-4 shadow-soft">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="text-center">
            <div className="text-2xl font-bold text-secondary">
              {formatTime(sessionTime)}
            </div>
            <div className="text-sm text-muted-foreground">Session Time</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-accent">
              {Math.round(accuracy)}%
            </div>
            <div className="text-sm text-muted-foreground">Step Accuracy</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-primary">
              {Math.round(sessionProgress)}%
            </div>
            <div className="text-sm text-muted-foreground">Progress</div>
          </div>
        </div>
        
        <Progress value={sessionProgress} className="h-2" />
        
        {sessionProgress > 0 && (
          <div className="text-center text-sm text-muted-foreground">
            {sessionProgress < 100 
              ? "Great job! Keep matching your steps to the beat."
              : "Session complete! Click Complete to save your progress."
            }
          </div>
        )}
      </Card>
    </div>
  );
};