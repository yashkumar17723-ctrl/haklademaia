import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Play, Pause, RotateCcw } from 'lucide-react';
import { BeatVisualizer } from './BeatVisualizer';

interface PatientInterfaceProps {
  targetBPM: number;
  onProgressUpdate: (progress: { accuracy: number; session_time: number }) => void;
}

export const PatientInterface = ({ targetBPM, onProgressUpdate }: PatientInterfaceProps) => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [sessionTime, setSessionTime] = useState(0);
  const [currentBPM, setCurrentBPM] = useState(targetBPM);
  const [accuracy, setAccuracy] = useState(85);
  const [sessionProgress, setSessionProgress] = useState(0);

  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (isPlaying) {
      interval = setInterval(() => {
        setSessionTime(prev => prev + 1);
        setSessionProgress(prev => Math.min(prev + 0.33, 100)); // 5-minute session
        
        // Simulate adaptive BPM adjustment
        const variation = Math.sin(Date.now() / 2000) * 2;
        setCurrentBPM(targetBPM + variation);
        
        // Simulate changing accuracy
        const newAccuracy = 75 + Math.random() * 20;
        setAccuracy(newAccuracy);
        
        onProgressUpdate({ accuracy: newAccuracy, session_time: sessionTime });
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [isPlaying, sessionTime, targetBPM, onProgressUpdate]);

  const handleStartStop = () => {
    setIsPlaying(!isPlaying);
  };

  const handleReset = () => {
    setIsPlaying(false);
    setSessionTime(0);
    setSessionProgress(0);
    setAccuracy(85);
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="text-center space-y-2">
        <h2 className="text-3xl font-bold text-foreground">Gait Training Session</h2>
        <p className="text-muted-foreground text-lg">
          Sync your steps with the rhythm below
        </p>
      </div>

      {/* Main Control Card */}
      <Card className="p-8 space-y-6 shadow-medical">
        <div className="text-center space-y-4">
          <div className="text-6xl font-bold text-primary">
            {Math.round(currentBPM)}
          </div>
          <div className="text-sm text-muted-foreground uppercase tracking-wide">
            Beats Per Minute
          </div>
        </div>

        {/* Beat Visualizer */}
        <BeatVisualizer isPlaying={isPlaying} bpm={currentBPM} />

        {/* Controls */}
        <div className="flex justify-center space-x-4">
          <Button
            size="lg"
            onClick={handleStartStop}
            className="w-20 h-20 rounded-full text-lg shadow-therapeutic"
            variant={isPlaying ? "secondary" : "default"}
          >
            {isPlaying ? <Pause className="w-8 h-8" /> : <Play className="w-8 h-8" />}
          </Button>
          <Button
            size="lg"
            variant="outline"
            onClick={handleReset}
            className="w-20 h-20 rounded-full"
          >
            <RotateCcw className="w-6 h-6" />
          </Button>
        </div>
      </Card>

      {/* Progress Panel */}
      <Card className="p-6 space-y-4 shadow-soft">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="text-center">
            <div className="text-2xl font-bold text-secondary">
              {formatTime(sessionTime)}
            </div>
            <div className="text-sm text-muted-foreground">Session Time</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-accent">
              {Math.round(accuracy)}%
            </div>
            <div className="text-sm text-muted-foreground">Step Accuracy</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-primary">
              {Math.round(sessionProgress)}%
            </div>
            <div className="text-sm text-muted-foreground">Progress</div>
          </div>
        </div>
        
        <Progress value={sessionProgress} className="h-2" />
        
        {sessionProgress > 0 && (
          <div className="text-center text-sm text-muted-foreground">
            Great job! Keep matching your steps to the beat.
          </div>
        )}
      </Card>
    </div>
  );
};