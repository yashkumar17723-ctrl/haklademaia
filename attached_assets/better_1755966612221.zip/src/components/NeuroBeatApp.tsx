import { useState, useEffect } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { EnhancedPatientInterface } from './EnhancedPatientInterface';
import { EnhancedClinicianDashboard } from './EnhancedClinicianDashboard';
import { Activity, Stethoscope, Brain } from 'lucide-react';
import { useAuth } from '@/hooks/useAuth';
import heroImage from '@/assets/neurobeat-hero.jpg';

interface PatientProgress {
  accuracy: number;
  session_time: number;
}

export const NeuroBeatApp = () => {
  const [currentBPM, setCurrentBPM] = useState(120);
  const [patientProgress, setPatientProgress] = useState<PatientProgress>({
    accuracy: 85,
    session_time: 0
  });
  
  const { profile } = useAuth();

  const handleProgressUpdate = (progress: PatientProgress) => {
    setPatientProgress(progress);
  };

  const handleBPMChange = (newBPM: number) => {
    setCurrentBPM(newBPM);
  };

  // Set initial BPM from user profile
  useEffect(() => {
    if (profile?.target_bpm) {
      setCurrentBPM(profile.target_bpm);
    }
  }, [profile]);

  const defaultTab = profile?.role === 'clinician' ? 'clinician' : 'patient';

  return (
    <div className="min-h-screen bg-gradient-calm">
      {/* Hero Section */}
      <div className="relative overflow-hidden">
        <div className="absolute inset-0">
          <img 
            src={heroImage} 
            alt="NeuroBeat therapy visualization" 
            className="w-full h-64 object-cover opacity-20"
          />
          <div className="absolute inset-0 bg-gradient-medical opacity-10" />
        </div>
        
        <div className="relative max-w-7xl mx-auto px-4 py-16">
          <div className="text-center space-y-4">
            <div className="flex justify-center items-center space-x-2 mb-4">
              <Brain className="w-10 h-10 text-primary" />
              <h1 className="text-4xl font-bold text-foreground">NeuroBeat</h1>
            </div>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              AI-powered music therapy for Parkinson's & stroke neurorehabilitation
            </p>
            <div className="flex justify-center space-x-2">
              <Badge variant="secondary" className="flex items-center space-x-1">
                <Activity className="w-4 h-4" />
                <span>Auditory-Motor Entrainment</span>
              </Badge>
              <Badge variant="outline" className="flex items-center space-x-1">
                <Stethoscope className="w-4 h-4" />
                <span>Clinical Grade</span>
              </Badge>
            </div>
          </div>
        </div>
      </div>

      {/* Main Interface */}
      <div className="max-w-7xl mx-auto px-4 pb-16">
        <Tabs defaultValue={defaultTab} className="space-y-8">
          <div className="flex justify-center">
            <TabsList className="grid w-full max-w-md mx-auto grid-cols-2 shadow-soft">
              <TabsTrigger value="patient" className="flex items-center space-x-2 text-base">
                <Activity className="w-4 h-4" />
                <span>Patient View</span>
              </TabsTrigger>
              <TabsTrigger value="clinician" className="flex items-center space-x-2 text-base">
                <Stethoscope className="w-4 h-4" />
                <span>Clinician View</span>
              </TabsTrigger>
            </TabsList>
          </div>

          <TabsContent value="patient" className="space-y-0">
            <Card className="p-8 shadow-medical bg-card/80 backdrop-blur-sm">
              <EnhancedPatientInterface 
                targetBPM={currentBPM}
                onProgressUpdate={handleProgressUpdate}
              />
            </Card>
          </TabsContent>

          <TabsContent value="clinician" className="space-y-0">
            <Card className="p-8 shadow-medical bg-card/80 backdrop-blur-sm">
              <EnhancedClinicianDashboard
                currentBPM={currentBPM}
                onBPMChange={handleBPMChange}
                patientProgress={patientProgress}
              />
            </Card>
          </TabsContent>
        </Tabs>

        {/* Features Overview */}
        <div className="mt-16 grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card className="p-6 text-center space-y-3 shadow-soft hover:shadow-therapeutic transition-all duration-300">
            <div className="w-12 h-12 mx-auto bg-gradient-medical rounded-full flex items-center justify-center">
              <Activity className="w-6 h-6 text-white" />
            </div>
            <h3 className="text-lg font-semibold">Adaptive Rhythms</h3>
            <p className="text-sm text-muted-foreground">
              AI adjusts beat tempo in real-time based on patient performance
            </p>
          </Card>

          <Card className="p-6 text-center space-y-3 shadow-soft hover:shadow-therapeutic transition-all duration-300">
            <div className="w-12 h-12 mx-auto bg-secondary rounded-full flex items-center justify-center">
              <Brain className="w-6 h-6 text-white" />
            </div>
            <h3 className="text-lg font-semibold">Neural Pathways</h3>
            <p className="text-sm text-muted-foreground">
              Bypasses damaged motor circuits through auditory-motor entrainment
            </p>
          </Card>

          <Card className="p-6 text-center space-y-3 shadow-soft hover:shadow-therapeutic transition-all duration-300">
            <div className="w-12 h-12 mx-auto bg-accent rounded-full flex items-center justify-center">
              <Stethoscope className="w-6 h-6 text-white" />
            </div>
            <h3 className="text-lg font-semibold">Clinical Monitoring</h3>
            <p className="text-sm text-muted-foreground">
              Real-time progress tracking with detailed analytics for clinicians
            </p>
          </Card>
        </div>
      </div>
    </div>
  );
};