import { useState, useEffect } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Settings, TrendingUp, User, Clock, LogOut, Users, Activity } from 'lucide-react';
import { useAuth } from '@/hooks/useAuth';
import { getPatientSessions, getPatientAnalytics, supabase } from '@/lib/supabase';
import { useToast } from '@/hooks/use-toast';

interface PatientData {
  id: string;
  full_name: string;
  condition: 'parkinsons' | 'stroke' | 'other';
  baseline_bpm: number;
  target_bpm: number;
}

interface PatientProgress {
  accuracy: number;
  session_time: number;
}

interface EnhancedClinicianDashboardProps {
  currentBPM: number;
  onBPMChange: (bpm: number) => void;
  patientProgress: PatientProgress;
}

export const EnhancedClinicianDashboard = ({ 
  currentBPM, 
  onBPMChange, 
  patientProgress 
}: EnhancedClinicianDashboardProps) => {
  const [targetBPM, setTargetBPM] = useState(currentBPM);
  const [selectedPatientId, setSelectedPatientId] = useState<string>('');
  const [patients, setPatients] = useState<PatientData[]>([]);
  const [patientSessions, setPatientSessions] = useState<any[]>([]);
  const [patientAnalytics, setPatientAnalytics] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);

  const { user, profile, signOut } = useAuth();
  const { toast } = useToast();

  useEffect(() => {
    loadPatients();
  }, []);

  useEffect(() => {
    if (selectedPatientId) {
      loadPatientData(selectedPatientId);
    }
  }, [selectedPatientId]);

  const loadPatients = async () => {
    setLoading(true);
    try {
      // Get patients assigned to this clinician - simplified query for demo
      const { data: patientProfiles, error } = await supabase
        .from('profiles')
        .select('id, full_name, condition, baseline_bpm, target_bpm')
        .eq('role', 'patient');

      if (error) throw error;

      // For demo purposes, show all patients. In production, filter by clinician assignment
      const patientList = patientProfiles || [];
      setPatients(patientList);
      
      if (patientList.length > 0 && !selectedPatientId) {
        setSelectedPatientId(patientList[0].id);
      }
    } catch (error) {
      console.error('Error loading patients:', error);
      toast({
        title: "Error loading patients",
        description: "Could not load patient list.",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const loadPatientData = async (patientId: string) => {
    try {
      // Load recent sessions
      const { data: sessions, error: sessionsError } = await getPatientSessions(patientId);
      if (sessionsError) throw sessionsError;
      setPatientSessions(sessions || []);

      // Load analytics
      const { data: analytics, error: analyticsError } = await getPatientAnalytics(patientId);
      if (analyticsError) throw analyticsError;
      setPatientAnalytics(analytics || []);
    } catch (error) {
      console.error('Error loading patient data:', error);
    }
  };

  const handleBPMUpdate = async () => {
    if (selectedPatientId) {
      try {
        const { error } = await supabase
          .from('profiles')
          .update({ target_bpm: targetBPM })
          .eq('id', selectedPatientId);

        if (error) throw error;

        onBPMChange(targetBPM);
        
        toast({
          title: "BPM Updated",
          description: `Target BPM set to ${targetBPM} for patient.`,
        });
      } catch (error) {
        toast({
          title: "Error updating BPM",
          description: "Could not update patient target BPM.",
          variant: "destructive"
        });
      }
    }
  };

  const getAccuracyColor = (accuracy: number) => {
    if (accuracy >= 85) return 'text-success';
    if (accuracy >= 70) return 'text-accent';
    return 'text-destructive';
  };

  const selectedPatient = patients.find(p => p.id === selectedPatientId);
  const averageAccuracy = patientAnalytics.find(a => a.metric_name === 'average_accuracy')?.metric_value || 0;
  const sessionCount = patientAnalytics.find(a => a.metric_name === 'session_count')?.metric_value || 0;

  return (
    <div className="space-y-6">
      {/* Header with clinician info */}
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-foreground">Dr. {profile?.full_name}</h2>
          <div className="flex items-center space-x-2 mt-1">
            <Badge variant="secondary">
              <Users className="w-4 h-4 mr-1" />
              {patients.length} Patients
            </Badge>
            <Badge variant="outline">Clinician</Badge>
          </div>
        </div>
        <Button variant="outline" onClick={signOut} className="flex items-center space-x-2">
          <LogOut className="w-4 h-4" />
          <span>Sign Out</span>
        </Button>
      </div>

      {/* Patient Selection */}
      <Card className="p-6 space-y-4 shadow-soft">
        <div className="flex items-center space-x-2">
          <User className="w-5 h-5 text-primary" />
          <h3 className="text-lg font-semibold">Patient Selection</h3>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label htmlFor="patient-select">Select Patient</Label>
            <Select value={selectedPatientId} onValueChange={setSelectedPatientId}>
              <SelectTrigger>
                <SelectValue placeholder="Choose a patient" />
              </SelectTrigger>
              <SelectContent>
                {patients.map((patient) => (
                  <SelectItem key={patient.id} value={patient.id}>
                    <div className="flex items-center space-x-2">
                      <span>{patient.full_name}</span>
                      <Badge variant="outline" className="text-xs">
                        {patient.condition === 'parkinsons' ? "Parkinson's" : 
                         patient.condition === 'stroke' ? "Stroke" : "Other"}
                      </Badge>
                    </div>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          
          {selectedPatient && (
            <div className="space-y-2">
              <Label>Patient Info</Label>
              <div className="p-3 bg-muted rounded-md">
                <div className="text-sm">
                  <p className="font-medium">{selectedPatient.full_name}</p>
                  <p className="text-muted-foreground">
                    Baseline: {selectedPatient.baseline_bpm} BPM
                  </p>
                </div>
              </div>
            </div>
          )}
        </div>
      </Card>

      {/* BPM Control Card */}
      {selectedPatient && (
        <Card className="p-6 space-y-4 shadow-medical">
          <div className="flex items-center space-x-2">
            <TrendingUp className="w-5 h-5 text-primary" />
            <h3 className="text-lg font-semibold">Tempo Control</h3>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="space-y-2">
              <Label htmlFor="baseline-bpm">Baseline BPM</Label>
              <div className="text-2xl font-bold text-muted-foreground">
                {selectedPatient.baseline_bpm}
              </div>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="current-bpm">Current BPM</Label>
              <div className="text-2xl font-bold text-primary">
                {currentBPM}
              </div>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="target-bpm">Target BPM</Label>
              <div className="flex space-x-2">
                <Input
                  id="target-bpm"
                  type="number"
                  value={targetBPM}
                  onChange={(e) => setTargetBPM(Number(e.target.value))}
                  min="60"
                  max="180"
                  className="text-lg"
                />
                <Button onClick={handleBPMUpdate} variant="secondary">
                  Update
                </Button>
              </div>
            </div>
          </div>
          
          <Progress value={(currentBPM / 180) * 100} className="h-2" />
        </Card>
      )}

      {/* Patient Analytics */}
      {selectedPatient && (
        <Card className="p-6 space-y-4 shadow-therapeutic">
          <div className="flex items-center space-x-2">
            <Activity className="w-5 h-5 text-secondary" />
            <h3 className="text-lg font-semibold">Patient Analytics (Weekly)</h3>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="text-center">
              <div className={`text-3xl font-bold ${getAccuracyColor(averageAccuracy)}`}>
                {Math.round(averageAccuracy)}%
              </div>
              <div className="text-sm text-muted-foreground">Average Accuracy</div>
              <Progress value={averageAccuracy} className="mt-2 h-2" />
            </div>
            
            <div className="text-center">
              <div className="text-3xl font-bold text-accent">
                {sessionCount}
              </div>
              <div className="text-sm text-muted-foreground">Sessions Completed</div>
              <Progress value={(sessionCount / 10) * 100} className="mt-2 h-2" />
            </div>
            
            <div className="text-center">
              <div className="text-3xl font-bold text-primary">
                {patientSessions.length > 0 ? 
                  Math.floor(patientSessions[0]?.session_duration / 60) || 0 : 0}
              </div>
              <div className="text-sm text-muted-foreground">Last Session (min)</div>
            </div>
          </div>
        </Card>
      )}

      {/* Recent Sessions */}
      {selectedPatient && patientSessions.length > 0 && (
        <Card className="p-6 space-y-4 shadow-soft">
          <div className="flex items-center space-x-2">
            <Clock className="w-5 h-5 text-accent" />
            <h3 className="text-lg font-semibold">Recent Sessions</h3>
          </div>
          
          <div className="space-y-2">
            {patientSessions.slice(0, 5).map((session) => (
              <div key={session.id} className="flex items-center justify-between p-3 bg-muted rounded-md">
                <div>
                  <div className="font-medium">{session.session_type.replace('_', ' ').toUpperCase()}</div>
                  <div className="text-sm text-muted-foreground">
                    {new Date(session.created_at).toLocaleDateString()}
                  </div>
                </div>
                <div className="text-right">
                  <div className="font-bold">{Math.floor(session.session_duration / 60)}:{(session.session_duration % 60).toString().padStart(2, '0')}</div>
                  <Badge variant={session.status === 'completed' ? 'default' : 'secondary'}>
                    {session.status}
                  </Badge>
                </div>
              </div>
            ))}
          </div>
        </Card>
      )}

      {/* AI Recommendations */}
      {selectedPatient && (
        <Card className="p-6 space-y-3 bg-gradient-calm shadow-soft">
          <div className="flex items-center space-x-2">
            <Settings className="w-5 h-5 text-primary" />
            <h3 className="text-lg font-semibold">AI Recommendations</h3>
          </div>
          <div className="space-y-2 text-sm">
            {averageAccuracy > 85 && (
              <div className="flex items-center space-x-2 text-success">
                <div className="w-2 h-2 bg-success rounded-full" />
                <span>Excellent performance! Consider increasing target BPM by 5-10 beats.</span>
              </div>
            )}
            {averageAccuracy < 70 && (
              <div className="flex items-center space-x-2 text-accent">
                <div className="w-2 h-2 bg-accent rounded-full" />
                <span>Accuracy below target. Consider reducing BPM by 5 beats or extending sessions.</span>
              </div>
            )}
            {sessionCount < 3 && (
              <div className="flex items-center space-x-2 text-primary">
                <div className="w-2 h-2 bg-primary rounded-full" />
                <span>Encourage more frequent sessions for optimal progress.</span>
              </div>
            )}
            <div className="flex items-center space-x-2 text-muted-foreground">
              <div className="w-2 h-2 bg-muted-foreground rounded-full" />
              <span>Patient shows consistent engagement with therapy protocols.</span>
            </div>
          </div>
        </Card>
      )}
    </div>
  );
};