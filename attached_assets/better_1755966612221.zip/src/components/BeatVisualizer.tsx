import { useEffect, useState } from 'react';

interface BeatVisualizerProps {
  isPlaying: boolean;
  bpm: number;
}

export const BeatVisualizer = ({ isPlaying, bpm }: BeatVisualizerProps) => {
  const [beatIndex, setBeatIndex] = useState(0);
  const [audioContext, setAudioContext] = useState<AudioContext | null>(null);

  useEffect(() => {
    // Initialize Web Audio API
    if (!audioContext && isPlaying) {
      const ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
      setAudioContext(ctx);
    }
  }, [isPlaying, audioContext]);

  useEffect(() => {
    let interval: NodeJS.Timeout;
    
    if (isPlaying && bpm > 0) {
      const beatInterval = (60 / bpm) * 1000; // Convert BPM to milliseconds
      
      interval = setInterval(() => {
        setBeatIndex(prev => (prev + 1) % 4);
        
        // Generate beat sound
        if (audioContext) {
          const oscillator = audioContext.createOscillator();
          const gainNode = audioContext.createGain();
          
          oscillator.connect(gainNode);
          gainNode.connect(audioContext.destination);
          
          oscillator.frequency.setValueAtTime(800, audioContext.currentTime);
          oscillator.type = 'sine';
          
          gainNode.gain.setValueAtTime(0, audioContext.currentTime);
          gainNode.gain.linearRampToValueAtTime(0.3, audioContext.currentTime + 0.01);
          gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.1);
          
          oscillator.start(audioContext.currentTime);
          oscillator.stop(audioContext.currentTime + 0.1);
        }
      }, beatInterval);
    }
    
    return () => clearInterval(interval);
  }, [isPlaying, bpm, audioContext]);

  const circles = [0, 1, 2, 3];

  return (
    <div className="flex justify-center items-center space-x-4 py-8">
      {circles.map((index) => (
        <div
          key={index}
          className={`w-16 h-16 rounded-full border-4 transition-all duration-200 ${
            beatIndex === index && isPlaying
              ? 'bg-gradient-pulse border-accent scale-110 shadow-therapeutic'
              : 'bg-secondary-soft border-border'
          }`}
        />
      ))}
      
      {/* Waveform visualization */}
      <div className="absolute inset-x-0 bottom-0 h-1 overflow-hidden">
        <div 
          className={`h-full bg-gradient-medical transition-all duration-300 ${
            isPlaying ? 'animate-pulse' : 'opacity-50'
          }`}
          style={{
            width: `${isPlaying ? (beatIndex + 1) * 25 : 0}%`,
          }}
        />
      </div>
    </div>
  );
};