import { useState } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Settings, TrendingUp, User, Clock } from 'lucide-react';

interface PatientProgress {
  accuracy: number;
  session_time: number;
}

interface ClinicianDashboardProps {
  currentBPM: number;
  onBPMChange: (bpm: number) => void;
  patientProgress: PatientProgress;
}

export const ClinicianDashboard = ({ 
  currentBPM, 
  onBPMChange, 
  patientProgress 
}: ClinicianDashboardProps) => {
  const [targetBPM, setTargetBPM] = useState(currentBPM);
  const [patientName] = useState("John D.");
  const [condition] = useState("Parkinson's Disease");

  const handleBPMUpdate = () => {
    onBPMChange(targetBPM);
  };

  const getAccuracyColor = (accuracy: number) => {
    if (accuracy >= 85) return 'text-success';
    if (accuracy >= 70) return 'text-accent';
    return 'text-destructive';
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-foreground">Clinician Dashboard</h2>
          <p className="text-muted-foreground">Monitor and adjust patient therapy</p>
        </div>
        <Badge variant="outline" className="text-sm">
          <Settings className="w-4 h-4 mr-1" />
          Active Session
        </Badge>
      </div>

      {/* Patient Info Card */}
      <Card className="p-6 shadow-soft">
        <div className="flex items-center space-x-4">
          <div className="w-12 h-12 bg-gradient-medical rounded-full flex items-center justify-center">
            <User className="w-6 h-6 text-white" />
          </div>
          <div>
            <h3 className="text-lg font-semibold">{patientName}</h3>
            <p className="text-muted-foreground">{condition}</p>
          </div>
        </div>
      </Card>

      {/* BPM Control Card */}
      <Card className="p-6 space-y-4 shadow-medical">
        <div className="flex items-center space-x-2">
          <TrendingUp className="w-5 h-5 text-primary" />
          <h3 className="text-lg font-semibold">Tempo Control</h3>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label htmlFor="current-bpm">Current BPM</Label>
            <div className="text-3xl font-bold text-primary">
              {currentBPM}
            </div>
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="target-bpm">Target BPM</Label>
            <div className="flex space-x-2">
              <Input
                id="target-bpm"
                type="number"
                value={targetBPM}
                onChange={(e) => setTargetBPM(Number(e.target.value))}
                min="60"
                max="180"
                className="text-lg"
              />
              <Button onClick={handleBPMUpdate} variant="secondary">
                Update
              </Button>
            </div>
          </div>
        </div>
        
        <Progress value={(currentBPM / 180) * 100} className="h-2" />
      </Card>

      {/* Progress Monitoring Card */}
      <Card className="p-6 space-y-4 shadow-therapeutic">
        <div className="flex items-center space-x-2">
          <Clock className="w-5 h-5 text-secondary" />
          <h3 className="text-lg font-semibold">Session Progress</h3>
        </div>
        
        <div className="grid grid-cols-2 gap-6">
          <div className="text-center">
            <div className={`text-3xl font-bold ${getAccuracyColor(patientProgress.accuracy)}`}>
              {Math.round(patientProgress.accuracy)}%
            </div>
            <div className="text-sm text-muted-foreground">Step Accuracy</div>
            <Progress 
              value={patientProgress.accuracy} 
              className="mt-2 h-2" 
            />
          </div>
          
          <div className="text-center">
            <div className="text-3xl font-bold text-accent">
              {Math.floor(patientProgress.session_time / 60)}:{(patientProgress.session_time % 60).toString().padStart(2, '0')}
            </div>
            <div className="text-sm text-muted-foreground">Session Duration</div>
            <Progress 
              value={(patientProgress.session_time / 300) * 100} // 5-minute session
              className="mt-2 h-2" 
            />
          </div>
        </div>
      </Card>

      {/* Recommendations */}
      <Card className="p-6 space-y-3 bg-gradient-calm shadow-soft">
        <h3 className="text-lg font-semibold">AI Recommendations</h3>
        <div className="space-y-2 text-sm">
          {patientProgress.accuracy > 85 && (
            <div className="flex items-center space-x-2 text-success">
              <div className="w-2 h-2 bg-success rounded-full" />
              <span>Excellent performance! Consider increasing BPM by 5-10 beats.</span>
            </div>
          )}
          {patientProgress.accuracy < 70 && (
            <div className="flex items-center space-x-2 text-accent">
              <div className="w-2 h-2 bg-accent rounded-full" />
              <span>Accuracy below target. Consider reducing BPM by 5 beats.</span>
            </div>
          )}
          <div className="flex items-center space-x-2 text-muted-foreground">
            <div className="w-2 h-2 bg-muted-foreground rounded-full" />
            <span>Patient shows consistent improvement in gait stability.</span>
          </div>
        </div>
      </Card>
    </div>
  );
};